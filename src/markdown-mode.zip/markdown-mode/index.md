title: Emacs Markdown Mode
description: A major mode for GNU Emacs for editing Markdown-formatted text files.
markup: markdown
icon: emacs
city: Columbus
created: May 24, 2007 23:47 GMT
modified: July 27, 2012 01:21 HKT

markdown-mode is a major mode for editing [Markdown][]-formatted
text files in GNU Emacs.  markdown-mode is free software, licensed
under the GNU GPL.

 [Markdown]: http://daringfireball.net/projects/markdown/

The latest stable version is markdown-mode 1.8.1, released on August 15, 2011:

   * [markdown-mode.el][]
   * [Screenshot][]
   * [Release notes][]

 [markdown-mode.el]: http://jblevins.org/projects/markdown-mode/markdown-mode.el
 [screenshot]: http://jblevins.org/projects/markdown-mode/screenshots/20110812-001.png
 [release notes]: http://jblevins.org/projects/markdown-mode/rev-1-8-1

markdown-mode is also available in several package managers, including:

   * Debian and Ubuntu Linux: [emacs-goodies-el][]
   * RedHat and Fedora Linux: [emacs-goodies][]
   * OpenBSD: [textproc/markdown-mode][]
   * Arch Linux (AUR): [emacs-markdown-mode-git][]

 [emacs-goodies-el]: http://packages.debian.org/emacs-goodies-el
 [emacs-goodies]: https://admin.fedoraproject.org/pkgdb/acls/name/emacs-goodies
 [textproc/markdown-mode]: http://pkgsrc.se/textproc/markdown-mode
 [emacs-markdown-mode-git]: http://aur.archlinux.org/packages.php?ID=30389

The latest development version can be downloaded directly
([markdown-mode.el][devel.el]) or it can be obtained from the
(browsable and clonable) Git repository at
<http://jblevins.org/git/markdown-mode.git>.  The entire repository,
including the full project history, can be cloned via the Git protocol
by running

    git clone git://jblevins.org/git/markdown-mode.git

 [devel.el]: http://jblevins.org/git/markdown-mode.git/plain/markdown-mode.el

n## Dependencies

markdown-mode requires easymenu, a standard package since GNU Emacs
19 and XEmacs 19, which provides a uniform interface for creating
menus in GNU Emacs and XEmacs.

n## Installation

Make sure to place `markdown-mode.el` somewhere in the load-path and add
the following lines to your `.emacs` file to associate markdown-mode
with `.text` files:

    (autoload 'markdown-mode "markdown-mode"
       "Major mode for editing Markdown files" t)
    (setq auto-mode-alist
       (cons '("\\.text" . markdown-mode) auto-mode-alist))

There is no consensus on an official file extension so change `.text` to
`.mdwn`, `.md`, `.mdt`, or whatever you call your markdown files.

n## Customization

Although no configuration is *necessary* there are a few things
that can be customized.  The <kbd>M-x customize-mode</kbd> command
provides an interface to all of the possible customizations:

  * `markdown-command` - the command used to run Markdown (default:
    `markdown`).  This variable may be customized to pass
    command-line options to your Markdown processor of choice, but
    this command must accept input from `stdin`.  If it does not, a
    simple wrapper script can be used to write `stdin` to a file
    and then pass that file to your Markdown interpreter.  Ideally,
    this command will produce an XHTML fragment around which
    markdown-mode will wrap a header and footer (which can be
    further customized).  However, it attempts to detect whether
    the command produces standalone XHTML output (via
    `markdown-xhtml-standalone-regexp`), in which case no header
    and footer content will be added.

  * `markdown-command-needs-filename` - set to non-nil if
    `markdown-command` does not accept input from stdin (default: nil).
     Instead, it will be passed a filename as the final command-line
     option.  As a result, you will only be able to run Markdown
     from buffers which are visiting a file.

  * `markdown-hr-string` - string to use when inserting horizontal
    rules (default: `* * * * *`).

  * `markdown-bold-underscore` - set to a non-nil value to use two
    underscores for bold instead of two asterisks (default: `nil`).

  * `markdown-italic-underscore` - set to a non-nil value to use
    underscores for italic instead of asterisks (default: `nil`).

  * `markdown-indent-function` - the function to use for automatic
    indentation (default: `markdown-indent-line`).

  * `markdown-indent-on-enter` - set to a non-nil value to
    automatically indent new lines when the enter key is pressed
    (default: `t`)

  * `markdown-follow-wiki-link-on-enter` - set to a non-nil value
    to automatically open a linked document in a new buffer if the
    cursor is an wiki link
    (default: `t`)

  * `markdown-wiki-link-alias-first` - set to a non-nil value to
    treat aliased wiki links like `[[link text|PageName]]`.
    When set to nil, they will be treated as `[[PageName|link text]]`.

  * `markdown-uri-types` - a list of protocols for URIs that
    `markdown-mode` should highlight.

  * `markdown-enable-math` - syntax highlighting for
    LaTeX fragments (default: `nil`).

  * `markdown-css-path` - CSS file to link to in XHTML output.

  * `markdown-xhtml-header-content` - additional content to include
    in the XHTML `<head>` block.

  * `markdown-xhtml-standalone-regexp` - a regular expression which
    indicates whether the output of `markdown-command` is standalone
    XHTML (default: `^\\(\<\?xml\\|\<!DOCTYPE\\|\<html\\)`).  If
    this is not matched, we assume this output is a fragment and add
    our own header and footer.

  * `markdown-link-space-sub-char` - a character to replace spaces
    when mapping wiki links to filenames (default: `_`).
    For example, use an underscore for compatibility with the
    Python Markdown WikiLinks extension or a hyphen for compatibility
    with Github wiki links.

Additionally, the faces used for syntax highlighting can be modified to
your liking by issuing <kbd>M-x customize-group RET markdown-faces</kbd>
or by using the "Markdown Faces" link at the bottom of the mode
customization screen.

n## Usage

Keybindings are grouped by prefixes based on their function.  For
example, commands dealing with headers begin with <kbd>C-c C-t</kbd>.  The
primary commands in each group will are described below.  You can
obtain a list of all keybindings by pressing <kbd>C-c C-h</kbd>.

  * Anchors: <kbd>C-c C-a</kbd>

    <kbd>C-c C-a l</kbd> inserts inline links of the form `[text](url)`.
    <kbd>C-c C-a r</kbd> inserts reference links of the form `[text][label]`.
    The label definition will be placed at the end of the current
    block. <kbd>C-c C-a w</kbd> acts similarly for wiki links of the form
    `[[WikiLink]]`. In all cases, if there is an active region, the
    text in the region is used as the link text.

  * Commands: <kbd>C-c C-c</kbd>

    <kbd>C-c C-c m</kbd> will run Markdown on the current buffer and preview
    the output in another buffer while <kbd>C-c C-c p</kbd> runs Markdown on
    the current buffer and previews the output in a browser.
    <kbd>C-c C-c e</kbd> will run Markdown on the current buffer and save
    the result in the file `basename.html`, where `basename` is the
    name of the Markdown file with the extension removed.  **This
    file will be overwritten without notice.**  Press <kbd>C-c C-c v</kbd>
    to view the exported file in a browser.

    <kbd>C-c C-c c</kbd> will check for undefined references.  If there are
    any, a small buffer will open with a list of undefined
    references and the line numbers on which they appear.  In Emacs
    22 and greater, selecting a reference from this list and
    pressing `RET` will insert an empty reference definition at the
    end of the buffer.  Similarly, selecting the line number will
    jump to the corresponding line.

  * Images: <kbd>C-c C-i</kbd>

    <kbd>C-c C-i i</kbd> inserts an image, using the active region (if any)
    as the alt text.

  * Physical styles: <kbd>C-c C-p</kbd>

    These commands all act on text in the active region, if any,
    and insert empty markup fragments otherwise.  <kbd>C-c C-p b</kbd> makes
    the selected text bold, <kbd>C-c C-p f</kbd> formats the region as
    fixed-width text, and <kbd>C-c C-p i</kbd> is used for italic text.

  * Logical styles: <kbd>C-c C-s</kbd>

    These commands all act on text in the active region, if any,
    and insert empty markup fragments otherwise.  Logical styles
    include blockquote (<kbd>C-c C-s b</kbd>), preformatted (<kbd>C-c C-s p</kbd>),
    code (<kbd>C-c C-s c</kbd>), emphasis (<kbd>C-c C-s e</kbd>), and strong
    (<kbd>C-c C-s s</kbd>).

  * Headers: <kbd>C-c C-t</kbd>

    All header commands use text in the active region, if any, as
    the header text.  To insert an atx or hash style level-n
    header, press <kbd>C-c C-t n</kbd> where n is between 1 and 6.  For a
    top-level setext or underline style header press <kbd>C-c C-t t</kbd>
    (mnemonic: title) and for a second-level underline-style header
    press <kbd>C-c C-t s</kbd> (mnemonic: section).

  * Footnotes: <kbd>C-c C-f</kbd>

    To create a new footnote at the point, press <kbd>C-c C-f n</kbd>.
    Press <kbd>C-c C-f g</kbd> with the point at a footnote to jump to the
    location where the footnote text is defined.  Then, press
    <kbd>C-c C-f b</kbd> to return to the footnote marker in the main text.

  * Other elements:

    <kbd>C-c -</kbd> inserts a horizontal rule.

  * Wiki-Link Navigation:

    Use <kbd>M-p</kbd> and <kbd>M-n</kbd> to quickly jump to the previous and next
    wiki links, respectively.

  * Outline Navigation:

    Navigation between headings is possible using `outline-mode`.
    Use <kbd>C-M-n</kbd> and <kbd>C-M-p</kbd> to move between the next and previous
    visible headings.  Similarly, <kbd>C-M-f</kbd> and <kbd>C-M-b</kbd> move to the
    next and previous visible headings at the same level as the one
    at the point.  Finally, <kbd>C-M-u</kbd> will move up to a lower-level
    (more inclusive) visible heading.

Many of the commands described above behave differently depending on
whether Transient Mark mode is enabled or not.  When it makes sense,
if Transient Mark mode is on and a region is active, the command
applies to the text in the region (e.g., <kbd>C-c C-p b</kbd> makes the region
bold).  For users who prefer to work outside of Transient Mark mode,
in Emacs 22 it can be enabled temporarily by pressing <kbd>C-SPC C-SPC</kbd>.

When applicable, commands that specifically act on the region even
outside of Transient Mark mode have the same keybinding as the with
the exception of an additional <kbd>C-</kbd> prefix.  For example,
`markdown-insert-blockquote` is bound to <kbd>C-c C-s b</kbd> and only acts on
the region in Transient Mark mode while `markdown-blockquote-region`
is bound to <kbd>C-c C-s C-b</kbd> and always applies to the region (when
nonempty).

markdown-mode attempts to be flexible in how it handles
indentation.  When you press `TAB` repeatedly, the point will cycle
through several possible indentation levels corresponding to things
you might have in mind when you press `RET` at the end of a line or
`TAB`.  For example, you may want to start a new list item,
continue a list item with hanging indentation, indent for a nested
pre block, and so on.

markdown-mode supports outline-minor-mode as well as org-mode-style
visibility cycling for atx- or hash-style headers.  There are two
types of visibility cycling: Pressing `S-TAB` cycles globally between
the table of contents view (headers only), outline view (top-level
headers only), and the full document view.  Pressing `TAB` while the
point is at a header will cycle through levels of visibility for the
subtree: completely folded, visible children, and fully visible.
Note that mixing hash and underline style headers will give undesired
results.

n## Extensions

Besides supporting the basic Markdown syntax, markdown-mode also
includes syntax highlighting for `[[Wiki Links]]` by default. Wiki
links may be followed automatically by hitting the enter key when
your curser is on a wiki link or by hitting <kbd>C-c C-w</kbd>. The
autofollowing on enter key may be controlled with the
`markdown-follow-wiki-link-on-enter` customization.  Use <kbd>M-p</kbd> and
<kbd>M-n</kbd> to quickly jump to the previous and next wiki links,
respectively.  Aliased or piped wiki links of the form
`[[link text|PageName]]` are also supported.  Since some wikis
reverse these components, set `markdown-wiki-link-alias-first`
to nil to treat them as `[[PageName|link text]]`.

[SmartyPants][] support is possible by customizing `markdown-command`.
If you install `SmartyPants.pl` at, say, `/usr/local/bin/smartypants`,
then you can set `markdown-command` to `"markdown | smartypants"`.
You can do this either by using <kbd>M-x customize-group markdown</kbd>
or by placing the following in your `.emacs` file:

    (defun markdown-custom ()
      "markdown-mode-hook"
      (setq markdown-command "markdown | smartypants"))
    (add-hook 'markdown-mode-hook '(lambda() (markdown-custom)))

[SmartyPants]: http://daringfireball.net/projects/smartypants/

Experimental syntax highlighting for mathematical expressions written
in LaTeX (only expressions denoted by `$..$`, `$$..$$`, or `\[..\]`)
can be enabled by setting `markdown-enable-math` to a non-nil value,
either via customize or by placing `(setq markdown-enable-itex t)`
in `.emacs`, and restarting Emacs.

A [GitHub Flavored Markdown](http://github.github.com/github-flavored-markdown/)
mode, `gfm-mode`, is also available.  The GitHub implementation of
differs slightly from standard Markdown.  Most importantly, newlines are
significant and trigger hard line breaks.  As such, `gfm-mode` turns off
`auto-fill-mode` and turns on `visual-line-mode` (or `longlines-mode` if
`visual-line-mode` is not available).  Wiki links in this mode will be
treated as on GitHub, with hyphens replacing spaces in filenames and
where the first letter of the filename capitalized.  For example,
`[[wiki link]]` will map to a file named `Wiki-link` with the same
extension as the current file.

n## Acknowledgments

markdown-mode has benefited greatly from the efforts of the
following people:

  * Cyril Brulebois for Debian packaging.
  * Conal Elliott for a font-lock regexp patch.
  * Edward O'Connor for a font-lock regexp fix and
    GitHub Flavored Markdown mode (`gfm-mode`).
  * Greg Bognar for menus and running
    `markdown` with an active region.
  * Daniel Burrows for filing Debian bug #456592.
  * Peter S. Galbraith for maintaining emacs-goodies-el.
  * Dmitry Dzhus for reference checking functions.
  * Bryan Kyle for indentation code.
  * Ben Voui for font-lock face customizations.
  * Ankit Solanki for longlines.el
    compatibility and custom CSS.
  * Hilko Bengen for proper XHTML output.
  * Jose A. Ortega Ruiz for Emacs 23 fixes.
  * Alec Resnick for bug reports.
  * Joost Kremers for bug reports
    regarding indentation.
  * Peter Williams for fill-paragraph
    enhancements.
  * George Ogata for fixing several
    byte-compilation warnings.
  * Eric Merritt for wiki link features.
  * Philippe Ivaldi for XHTML preview
    customizations and XHTML export.
  * Jeremiah Dodds for supporting
    Markdown processors which do not accept input from stdin.
  * Werner Dittmann for bug reports
    regarding the cl dependency and auto-fill-mode and indentation.
  * Scott Pfister for generalizing the space
    substitution character for mapping wiki links to filenames.
  * Marcin Kasperski for a patch to
    escape shell commands.
  * Christopher J. Madsen for patches to fix a match
    data bug and to prefer `visual-line-mode` in `gfm-mode`.
  * Shigeru Fukaya for better adherence to
    Emacs Lisp coding conventions.
  * Donald Curtis for fixing the `paragraph-fill` regexp.
  * Kevin Porter for wiki link handling in `gfm-mode`.

n## Bugs

Although markdown-mode is developed and tested primarily using
GNU Emacs 24, compatibility with earlier Emacsen is also a
priority.

If you find any bugs in markdown-mode, please construct a test case
or a patch and email me at <jrblevin@sdf.org>.

n## History

markdown-mode was written and is maintained by Jason Blevins.  The
first version was released on May 24, 2007.

  * 2007-05-24: Version 1.1
  * 2007-05-25: Version 1.2
  * 2007-06-05: [Version 1.3][]
  * 2007-06-29: Version 1.4
  * 2008-05-24: [Version 1.5][]
  * 2008-06-04: [Version 1.6][]
  * 2009-10-01: [Version 1.7][]
  * 2011-08-12: [Version 1.8][]
  * 2011-08-15: [Version 1.8.1][]

[Version 1.3]: http://jblevins.org/projects/markdown-mode/rev-1-3
[Version 1.5]: http://jblevins.org/projects/markdown-mode/rev-1-5
[Version 1.6]: http://jblevins.org/projects/markdown-mode/rev-1-6
[Version 1.7]: http://jblevins.org/projects/markdown-mode/rev-1-7
[Version 1.8]: http://jblevins.org/projects/markdown-mode/rev-1-8
[Version 1.8.1]: http://jblevins.org/projects/markdown-mode/rev-1-8-1

